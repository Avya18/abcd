#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32


class CorridorCenter(Node):

    def __init__(self):
        super().__init__('corridor_center')

        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10)

        self.error_pub = self.create_publisher(
            Float32,
            '/corridor_error',
            10)

        self.get_logger().info("Corridor Center Node Started")

    def scan_callback(self, msg):

        ranges = list(msg.ranges)

        # Replace invalid values
        for i in range(len(ranges)):
            if math.isinf(ranges[i]) or math.isnan(ranges[i]):
                ranges[i] = msg.range_max

        total = len(ranges)

        left_index = int(90 * total / 360)
        right_index = int(270 * total / 360)

        left_distance = ranges[left_index]
        right_distance = ranges[right_index]

        center_error = left_distance - right_distance

        msg_out = Float32()
        msg_out.data = center_error
        self.error_pub.publish(msg_out)

        self.get_logger().info(
            f"Left={left_distance:.2f} m  "
            f"Right={right_distance:.2f} m  "
            f"Error={center_error:.2f}"
        )


def main(args=None):

    rclpy.init(args=args)

    node = CorridorCenter()

    rclpy.spin(node)

    node.destroy_node()

    rclpy.shutdown()


if __name__ == '__main__':
    main()
